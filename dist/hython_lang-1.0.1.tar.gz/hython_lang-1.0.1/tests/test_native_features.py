import unittest
from hython.compiler import compile_source
from hython.vm import VM

class NativeFeatureTests(unittest.TestCase):
    def run_source(self, source):
        vm=VM(); vm.run(compile_source(source)); return vm.globals

    def test_dictionary_and_subscript_assignment(self):
        values=self.run_source('자료 = {"이름": "하이썬", "버전": 1}\n자료["버전"] = 자료["버전"] + 1\n결과 = 자료["버전"]\n')
        self.assertEqual(values["결과"],2)

    def test_attribute_and_boolean_expression(self):
        values=self.run_source('문자 = "hython"\n결과 = 문자.upper() == "HYTHON" 앤드 렌(문자) > 3\n')
        self.assertIs(values["결과"],True)

    def test_boolean_operators_short_circuit(self):
        values=self.run_source('횟수 = [0]\n데프 호출():\n    횟수[0] = 횟수[0] + 1\n    리턴 트루\n왼쪽 = 폴스 앤드 호출()\n오른쪽 = 트루 오어 호출()\n결과 = 횟수[0]\n')
        self.assertEqual(values["결과"],0)
