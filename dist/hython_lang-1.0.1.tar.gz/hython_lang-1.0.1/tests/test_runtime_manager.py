import tempfile
import unittest
from pathlib import Path
from hython.runtime_manager import get_preference, set_preference

class RuntimeManagerTests(unittest.TestCase):
    def test_project_runtime_is_inherited(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            child = root / "src" / "app"
            child.mkdir(parents=True)
            set_preference(root, "3.14")
            self.assertEqual(get_preference(child), "3.14")

    def test_rejects_invalid_tag(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(ValueError):
                set_preference(Path(directory), "3.14 bad")

