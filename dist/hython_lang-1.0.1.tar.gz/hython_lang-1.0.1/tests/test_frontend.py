import unittest
from hython.frontend import ParseError, parse

class FrontendTests(unittest.TestCase):
    def test_builds_hython_owned_ast(self):
        tree = parse("이프 값 >= 3:\n    프린트(값)\n엘스:\n    패스\n")
        self.assertEqual(tree.kind, "module")
        self.assertEqual(tree.children[0].kind, "if")
        self.assertEqual(tree.children[0].children[0].value, ">=")

    def test_reports_line_for_bad_assignment(self):
        with self.assertRaisesRegex(ParseError, "줄 1"):
            parse("1 = 2\n")

