import unittest

from hython.translator import compile_hython, to_hython, to_python


class TranslatorTests(unittest.TestCase):
    def test_executes_hython(self):
        namespace = {}
        exec(compile_hython("결과 = [수 * 2 포 수 인 레인지(3)]"), namespace)
        self.assertEqual(namespace["결과"], [0, 2, 4])

    def test_preserves_strings_and_comments(self):
        source = '프린트("프린트 인폴트")  # 프린트\n'
        translated = to_python(source)
        self.assertIn('"프린트 인폴트"', translated)
        self.assertIn("# 프린트", translated)
        self.assertTrue(translated.startswith("print"))

    def test_round_trip(self):
        source = "for n in range(2):\n    print(n)\n"
        self.assertEqual(to_python(to_hython(source)), source)


if __name__ == "__main__":
    unittest.main()

