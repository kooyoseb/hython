import tempfile
import unittest
from pathlib import Path
from hython.bytecode import write
from hython.compiler import compile_source
from hython.vm import VM, VMError

class NativeModuleTests(unittest.TestCase):
    def test_imports_verified_hbc_module(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            write(root/"계산.hbc",compile_source("데프 두배(값):\n    리턴 값 * 2\n",str(root/"계산.hy")))
            main=compile_source("인폴트 계산\n결과 = 계산.두배(21)\n",str(root/"main.hy"))
            vm=VM([root]); vm.run(main)
            self.assertEqual(vm.globals["결과"],42)

    def test_missing_native_module_is_clear(self):
        with self.assertRaisesRegex(VMError,"찾을 수 없습니다"):
            VM().run(compile_source("인폴트 없음\n"))
