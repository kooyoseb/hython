import unittest
from hython.compiler import compile_source
from hython.vm import VM

class NativeClassTests(unittest.TestCase):
    def test_class_constructor_attributes_and_bound_method(self):
        source='클래스 카운터:\n    데프 __init__(셀프, 시작):\n        셀프.값 = 시작\n    데프 증가(셀프):\n        셀프.값 = 셀프.값 + 1\n        리턴 셀프.값\n객체 = 카운터(40)\n객체.증가()\n결과 = 객체.증가()\n'
        vm=VM(); vm.run(compile_source(source)); self.assertEqual(vm.globals["결과"],42)
