import unittest
from hython.compiler import compile_source
from hython.vm import VM

class FStringTests(unittest.TestCase):
    def test_native_fstring(self):
        vm=VM(); vm.run(compile_source('이름 = "하이썬"\n결과 = f"안녕, {이름}!"\n'))
        self.assertEqual(vm.globals["결과"],"안녕, 하이썬!")
