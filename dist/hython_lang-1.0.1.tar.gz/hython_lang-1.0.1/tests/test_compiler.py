import unittest
from contextlib import redirect_stdout
from io import StringIO
from hython.bytecode import BytecodeError, CodeObject, dumps, loads
from hython.compiler import compile_source
from hython.vm import VM

class CompilerTests(unittest.TestCase):
    def test_compiles_and_runs_independent_bytecode(self):
        source = "데프 제곱(값):\n    리턴 값 * 값\n포 수 인 레인지(3):\n    프린트(제곱(수))\n"
        code = loads(dumps(compile_source(source)))
        output = StringIO()
        with redirect_stdout(output): VM().run(code)
        self.assertEqual(output.getvalue(), "0\n1\n4\n")

    def test_detects_tampering(self):
        data = bytearray(dumps(compile_source("값 = 1\n")))
        data[-1] ^= 1
        with self.assertRaises(BytecodeError): loads(bytes(data))

    def test_rejects_unknown_opcode_even_with_valid_checksum(self):
        data=dumps(CodeObject("악성",[],[],[["EXEC_PYTHON"]]))
        with self.assertRaisesRegex(BytecodeError,"허용되지 않은"): loads(data)

    def test_rejects_statically_detectable_stack_underflow(self):
        data=dumps(CodeObject("악성",[],[None],[["POP"],["CONST",0],["RETURN"]]))
        with self.assertRaisesRegex(BytecodeError,"스택 언더플로"): loads(data)
