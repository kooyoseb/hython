# 하이썬 (Hython)

**Python, pronounced in Hangul.** Python의 의미를 번역하지 않고 발음을 한글로 적는
난해한 프로그래밍 언어입니다.

```hython
데프 인사(이름):
    프린트(f"안녕, {이름}!")

포 번호 인 레인지(3):
    인사(번호)
```

## 설치와 실행

```console
python -m pip install -e .
hython run examples/안녕.hy
hython module 내패키지
hython repl
hython doctor
```

Python 파일을 하이썬으로 바꾸거나 그 반대로 바꿀 수 있습니다.

```console
hython translate program.py --reverse -o program.hy
hython translate program.hy -o program.py
```

하이썬 1.0은 Python 호환 실행 모드와 독립 HBC 컴파일 모드를 함께 제공합니다.
따라서 문자열과 주석 안의 단어는 바뀌지 않습니다. Python 문법의 괄호, 연산자,
들여쓰기 규칙은 그대로 사용합니다.

같은 폴더의 `계산기.hy`는 일반 모듈처럼 `인폴트 계산기`로 불러올 수 있습니다.
패키지는 `도구/__init__.hy` 형태로 만들며 상대 import도 지원합니다.

## Python 패키지와 발음 사전

```console
hython package install requests
hython package install beautifulsoup4 --module bs4
hython package scan pathlib
```

설치는 현재 Python의 `pip`를 사용합니다. 그 뒤 패키지를 실행하지 않고 `.py` 파일의
AST를 정적으로 읽어 공개 이름의 발음 사전을 `~/.hython/dictionaries`에 생성합니다.
사전은 JSON이므로 자동 발음이 마음에 들지 않으면 직접 고칠 수 있습니다.

## Python 런타임 동기화

```console
hython runtime info
hython runtime sync
hython runtime check .
```

`info`와 `sync`는 하드코딩된 버전 번호가 아니라 현재 Python의 `keyword` 모듈을
조사합니다. 새 키워드가 발견되면 발음 후보와 함께
`~/.hython/runtimes/python-버전.json`에 기록합니다. `check`는 코드를 실행하지 않고
모든 `.hy` 파일을 현재 Python 컴파일러로 문법 검사합니다.

### 공식 Python 런타임 관리 (Windows)

```console
hython runtime list
hython runtime online 3.14
hython runtime install 3.14 --dry-run
hython runtime install 3.14
hython runtime use 3.14
```

다운로드와 검증은 Python.org의 공식 Python install manager에 위임합니다. `use`는
프로젝트에 `.hython-runtime`을 만들고 이후 실행을 지정 버전으로 전환합니다.

## 독립 HBC 컴파일러와 VM

```console
hython compile examples/컴파일.hy -o 프로그램.hbc
hython compile examples/컴파일.hy --show-hir
hython compile examples/컴파일.hy --no-optimize
hython disassemble 프로그램.hbc
hython execute 프로그램.hbc
hython build . -o dist
```

HBC v1은 `HYBC` 헤더, 자체 스택 명령어, 압축 페이로드와 SHA-256 무결성 검사를
사용하며 `.pyc`나 CPython opcode가 아닙니다. 현재 산술, 변수, 비교, 조건문, 반복문,
함수, 리스트와 일부 내장 함수를 지원합니다. 네이티브 컴파일 경로는 하이썬 소유 AST와
Pratt 표현식 파서를 사용하며 `ast.parse`에 의존하지 않습니다.

0.7부터 소스 프런트엔드와 HBC 사이에 독립 HIR 계층이 있습니다. 기본 최적화는 숫자,
문자열과 비교식의 안전한 상수 접기를 수행하며 명령어 위치를 유지해 분기 안정성을
보존합니다. `--show-hir`로 결과를 확인할 수 있습니다.

여러 `.hy` 파일은 `hython build`로 디렉터리 구조를 유지한 채 한 번에 컴파일할 수
있습니다. HBC의 `인폴트 모듈`은 같은 출력 폴더의 `모듈.hbc`를 직접 로드합니다.

지원 범위와 두 실행 모드의 차이는 [언어 안내](docs/LANGUAGE.md)를 참고하세요.
신뢰 경계와 HBC 검증 범위는 [보안 정책](SECURITY.md)에 설명되어 있습니다.

## 1.0 안정성 검사

```console
python -m unittest discover -s tests -v
python scripts/stability.py --cycles 10
```

안정성 검사는 호환/네이티브 차등 계산, 10만 회 반복, 반복 함수 호출, 재귀,
대용량 컬렉션, 모듈 캐시 및 HBC 절단·변조 입력을 검사합니다.

## 목표

- 설치된 Python 버전에서 문법/키워드를 자동 검사
- 더 정확한 발음 규칙과 패키지별 공식 사전
- 독립 HIR/HBC/VM 컴파일러 ([설계 문서](docs/COMPILER.md))
- Python 새 버전 문법에 대한 호환성 검사 및 사전 업데이트

자동으로 내려받은 코드나 패키지는 실행 전 출처와 해시를 검증하는 방향으로 설계합니다.
