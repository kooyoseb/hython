"""Small stack VM for HBC v1."""
from __future__ import annotations
import operator
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace
from .bytecode import CodeObject
from .bytecode import read as read_hbc

class VMError(RuntimeError): pass

@dataclass
class Function:
    code: CodeObject
    globals: dict
    def __get__(self, instance, owner):
        if instance is None: return self
        return BoundFunction(self,instance)
    def __call__(self,*args):
        vm=VM(); vm.globals=self.globals
        if len(args)!=len(self.code.parameters): raise VMError("함수 인자 개수가 맞지 않습니다.")
        return vm.run(self.code,dict(zip(self.code.parameters,args)))

@dataclass
class BoundFunction:
    function: Function
    instance: object
    def __call__(self,*args): return self.function(self.instance,*args)

class VM:
    def __init__(self, module_paths: list[Path] | None = None, modules: dict | None = None):
        self.globals = {"print": print, "range": range, "len": len, "str": str, "int": int}
        self.module_paths = module_paths or [Path.cwd()]
        self.modules = modules if modules is not None else {}

    def import_module(self, name: str, parent_code: CodeObject):
        if name in self.modules:
            module = self.modules[name]
            if module is None: raise VMError(f"순환 모듈 import: {name}")
            return module
        source_path=Path(parent_code.name)
        candidates=[source_path.parent / f"{name}.hbc"]
        candidates.extend(path / f"{name}.hbc" for path in self.module_paths)
        path=next((candidate for candidate in candidates if candidate.is_file()),None)
        if path is None: raise VMError(f"HBC 모듈을 찾을 수 없습니다: {name}")
        self.modules[name]=None
        child=VM([path.parent,*self.module_paths],self.modules)
        child.run(read_hbc(path))
        builtins={"print","range","len","str","int"}
        public={key:value for key,value in child.globals.items() if not key.startswith("_") and key not in builtins}
        module=SimpleNamespace(**public); self.modules[name]=module; return module

    def run(self, code: CodeObject, locals_: dict | None = None):
        local = self.globals if locals_ is None else locals_
        stack=[]; ip=0; instructions=code.instructions
        binary={"ADD":operator.add,"SUB":operator.sub,"MUL":operator.mul,"DIV":operator.truediv,"FLOORDIV":operator.floordiv,"MOD":operator.mod,"POW":operator.pow,
                "EQ":operator.eq,"NE":operator.ne,"LT":operator.lt,"LE":operator.le,"GT":operator.gt,"GE":operator.ge,"IN":lambda a,b:a in b,"IS":operator.is_}
        while ip < len(instructions):
            ins=instructions[ip]; op=ins[0]; arg=ins[1] if len(ins)>1 else None; ip+=1
            if op=="CONST": stack.append(code.constants[arg])
            elif op=="LOAD":
                if arg in local: stack.append(local[arg])
                elif arg in self.globals: stack.append(self.globals[arg])
                else: raise VMError(f"정의되지 않은 이름: {arg}")
            elif op=="STORE": local[arg]=stack.pop()
            elif op=="POP": stack.pop()
            elif op in binary: b=stack.pop(); a=stack.pop(); stack.append(binary[op](a,b))
            elif op in ("NEG","POS","NOT"): stack.append({"NEG":operator.neg,"POS":operator.pos,"NOT":operator.not_}[op](stack.pop()))
            elif op=="JUMP": ip=arg
            elif op=="JUMP_FALSE":
                if not stack.pop(): ip=arg
            elif op=="JUMP_IF_FALSE_OR_POP":
                if not stack[-1]: ip=arg
                else: stack.pop()
            elif op=="JUMP_IF_TRUE_OR_POP":
                if stack[-1]: ip=arg
                else: stack.pop()
            elif op=="ITER": stack.append(iter(stack.pop()))
            elif op=="FOR_ITER":
                try: stack.append(next(stack[-1]))
                except StopIteration: stack.pop(); ip=arg
            elif op in ("BUILD_LIST","BUILD_TUPLE"):
                values=stack[-arg:] if arg else []
                if arg: del stack[-arg:]
                stack.append(list(values) if op=="BUILD_LIST" else tuple(values))
            elif op=="BUILD_DICT":
                values=stack[-arg*2:] if arg else []
                if arg: del stack[-arg*2:]
                stack.append(dict(zip(values[::2],values[1::2])))
            elif op=="GET_ITEM":
                index=stack.pop(); container=stack.pop(); stack.append(container[index])
            elif op=="SET_ITEM":
                value=stack.pop(); index=stack.pop(); container=stack.pop(); container[index]=value
            elif op=="GET_ATTR": stack.append(getattr(stack.pop(),arg))
            elif op=="SET_ATTR":
                value=stack.pop(); target=stack.pop(); setattr(target,arg,value)
            elif op=="IMPORT": stack.append(self.import_module(arg,code))
            elif op=="FORMAT": stack.append(str(stack.pop()))
            elif op=="BUILD_STRING":
                values=stack[-arg:] if arg else []
                if arg: del stack[-arg:]
                stack.append("".join(values))
            elif op=="MAKE_FUNCTION": stack.append(Function(CodeObject.from_dict(arg), self.globals))
            elif op=="MAKE_CLASS":
                class_code=CodeObject.from_dict(arg); namespace={}
                self.run(class_code,namespace)
                namespace.pop("__return__",None)
                stack.append(type(class_code.name,(),namespace))
            elif op=="CALL":
                args=stack[-arg:] if arg else []; 
                if arg: del stack[-arg:]
                function=stack.pop()
                if isinstance(function,BoundFunction):
                    args=[function.instance,*args]; function=function.function
                if isinstance(function, Function):
                    if len(args)!=len(function.code.parameters): raise VMError("함수 인자 개수가 맞지 않습니다.")
                    stack.append(self.run(function.code, dict(zip(function.code.parameters,args))))
                else: stack.append(function(*args))
            elif op=="RETURN": return stack.pop()
            elif op=="NOP": pass
            else: raise VMError(f"알 수 없는 HBC 명령어: {op}")
        return None
