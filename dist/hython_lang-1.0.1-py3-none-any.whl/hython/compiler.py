"""Bootstrap compiler from Hython source into independent HBC instructions."""
from __future__ import annotations
from .bytecode import CodeObject
from .hir import HIRCode, optimize_hir
from .frontend import Node, parse

class CompileError(SyntaxError):
    pass

class Compiler:
    def __init__(self, name: str = "<모듈>", parameters: list[str] | None = None):
        self.code = HIRCode(name, parameters or [], [], [])
        self.loops: list[tuple[int,list[int],bool]] = []

    def emit(self, op: str, arg=None) -> int:
        instruction = [op] if arg is None else [op, arg]
        self.code.instructions.append(instruction)
        return len(self.code.instructions) - 1

    def patch(self, index: int, target: int) -> None:
        self.code.instructions[index][1] = target

    def constant(self, value) -> int:
        self.code.constants.append(value)
        return len(self.code.constants) - 1

    def compile_body(self, body: list[Node]) -> HIRCode:
        for node in body:
            self.statement(node)
        self.emit("CONST", self.constant(None))
        self.emit("RETURN")
        return self.code

    def statement(self, node: Node) -> None:
        if node.kind == "expr":
            self.expression(node.children[0]); self.emit("POP")
        elif node.kind == "import":
            module, alias = node.value
            self.emit("IMPORT", module); self.emit("STORE", alias)
        elif node.kind == "assign":
            target, value = node.children
            if target.kind == "name":
                self.expression(value); self.emit("STORE", target.value)
            elif target.kind == "subscript":
                self.expression(target.children[0]); self.expression(target.children[1]); self.expression(value); self.emit("SET_ITEM")
            elif target.kind == "attribute":
                self.expression(target.children[0]); self.expression(value); self.emit("SET_ATTR", target.value)
            else: self.unsupported(target)
        elif node.kind == "augassign":
            name, operator = node.value
            self.emit("LOAD",name); self.expression(node.children[0])
            opcode={"+":"ADD","-":"SUB","*":"MUL","/":"DIV","//":"FLOORDIV","%":"MOD","**":"POW"}.get(operator)
            if not opcode: self.unsupported(node)
            self.emit(opcode); self.emit("STORE",name)
        elif node.kind == "if":
            self.expression(node.children[0]); false = self.emit("JUMP_FALSE", -1)
            for item in node.children[1].children: self.statement(item)
            end = self.emit("JUMP", -1); self.patch(false, len(self.code.instructions))
            for item in node.children[2].children: self.statement(item)
            self.patch(end, len(self.code.instructions))
        elif node.kind == "while":
            start = len(self.code.instructions); self.expression(node.children[0])
            end = self.emit("JUMP_FALSE", -1)
            breaks: list[int]=[]; self.loops.append((start,breaks,False))
            for item in node.children[1].children: self.statement(item)
            self.loops.pop()
            self.emit("JUMP", start); self.patch(end, len(self.code.instructions))
            for jump in breaks: self.patch(jump,len(self.code.instructions))
        elif node.kind == "for":
            self.expression(node.children[0]); self.emit("ITER"); start = len(self.code.instructions)
            end = self.emit("FOR_ITER", -1); self.emit("STORE", node.value)
            breaks=[]; self.loops.append((start,breaks,True))
            for item in node.children[1].children: self.statement(item)
            self.loops.pop()
            self.emit("JUMP", start); self.patch(end, len(self.code.instructions))
            for jump in breaks: self.patch(jump,len(self.code.instructions))
        elif node.kind == "def":
            name, params = node.value
            child = Compiler(name, params).compile_body(node.children)
            self.emit("MAKE_FUNCTION", child.to_dict()); self.emit("STORE", name)
        elif node.kind == "class":
            child=Compiler(node.value,[]).compile_body(node.children)
            self.emit("MAKE_CLASS",child.to_dict()); self.emit("STORE",node.value)
        elif node.kind == "return":
            self.expression(node.children[0]); self.emit("RETURN")
        elif node.kind == "pass":
            self.emit("NOP")
        elif node.kind == "break":
            if not self.loops: raise CompileError(f"루프 밖의 브레이크 (줄 {node.line})")
            if self.loops[-1][2]: self.emit("POP")
            self.loops[-1][1].append(self.emit("JUMP",-1))
        elif node.kind == "continue":
            if not self.loops: raise CompileError(f"루프 밖의 컨티뉴 (줄 {node.line})")
            self.emit("JUMP",self.loops[-1][0])
        else: self.unsupported(node)

    def expression(self, node: Node) -> None:
        if node.kind == "constant": self.emit("CONST", self.constant(node.value))
        elif node.kind == "name": self.emit("LOAD", node.value)
        elif node.kind == "binary":
            if node.value in ("and","or"):
                self.expression(node.children[0])
                jump=self.emit("JUMP_IF_FALSE_OR_POP" if node.value=="and" else "JUMP_IF_TRUE_OR_POP",-1)
                self.expression(node.children[1]); self.patch(jump,len(self.code.instructions)); return
            self.expression(node.children[0]); self.expression(node.children[1])
            ops = {"+":"ADD","-":"SUB","*":"MUL","/":"DIV","//":"FLOORDIV","%":"MOD","**":"POW",
                   "==":"EQ","!=":"NE","<":"LT","<=":"LE",">":"GT",">=":"GE","in":"IN","is":"IS"}
            op=ops.get(node.value); self.emit(op) if op else self.unsupported(node)
        elif node.kind == "unary":
            self.expression(node.children[0]); op={"-":"NEG","+":"POS","not":"NOT"}.get(node.value)
            self.emit(op) if op else self.unsupported(node)
        elif node.kind == "call":
            self.expression(node.children[0])
            for arg in node.children[1:]: self.expression(arg)
            self.emit("CALL", len(node.children)-1)
        elif node.kind == "list":
            for item in node.children: self.expression(item)
            self.emit("BUILD_LIST", len(node.children))
        elif node.kind == "dict":
            for pair in node.children:
                self.expression(pair.children[0]); self.expression(pair.children[1])
            self.emit("BUILD_DICT", len(node.children))
        elif node.kind == "subscript":
            self.expression(node.children[0]); self.expression(node.children[1]); self.emit("GET_ITEM")
        elif node.kind == "attribute":
            self.expression(node.children[0]); self.emit("GET_ATTR", node.value)
        elif node.kind == "format":
            self.expression(node.children[0]); self.emit("FORMAT")
        elif node.kind == "fstring":
            for item in node.children: self.expression(item)
            self.emit("BUILD_STRING",len(node.children))
        else: self.unsupported(node)

    def unsupported(self, node) -> None:
        raise CompileError(f"아직 지원하지 않는 구문: {node.kind} (줄 {node.line})")

def compile_hir(source: str, filename: str = "<하이썬>", *, optimize: bool = True) -> HIRCode:
    tree = parse(source)
    hir = Compiler(filename).compile_body(tree.children)
    return optimize_hir(hir) if optimize else hir

def _lower(hir: HIRCode) -> CodeObject:
    instructions: list[list] = []
    for instruction in hir.instructions:
        lowered = list(instruction)
        if lowered[0] in ("MAKE_FUNCTION","MAKE_CLASS"):
            nested = lowered[1]
            lowered[1] = _lower(HIRCode(nested["name"], nested["parameters"], nested["constants"], nested["instructions"])).to_dict()
        instructions.append(lowered)
    return CodeObject(hir.name, hir.parameters, hir.constants, instructions)

def compile_source(source: str, filename: str = "<하이썬>", *, optimize: bool = True) -> CodeObject:
    return _lower(compile_hir(source, filename, optimize=optimize))
