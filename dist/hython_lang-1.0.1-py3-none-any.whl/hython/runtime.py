"""Python runtime discovery and Hython syntax compatibility profiles."""

from __future__ import annotations

import json
import keyword
import platform
import sys
import sysconfig
from pathlib import Path

from .phonetics import pronounce_identifier
from .translator import to_python
from .vocabulary import KEYWORDS


def profile_dir() -> Path:
    path = Path.home() / ".hython" / "runtimes"
    path.mkdir(parents=True, exist_ok=True)
    return path


def inspect_runtime() -> dict:
    """Inspect the active interpreter instead of assuming a Python grammar version."""
    hard = sorted(keyword.kwlist)
    soft = sorted(getattr(keyword, "softkwlist", []))
    known = set(KEYWORDS)
    # Pattern wildcard `_` is intentionally identical in Hython.
    discovered = [name for name in hard + soft if name not in known and name != "_"]
    return {
        "format": 1,
        "implementation": platform.python_implementation(),
        "version": platform.python_version(),
        "version_info": list(sys.version_info[:3]),
        "executable": sys.executable,
        "platform": sysconfig.get_platform(),
        "hard_keywords": hard,
        "soft_keywords": soft,
        "new_keywords": discovered,
        "generated_spellings": {
            name: pronounce_identifier(name) for name in discovered
        },
    }


def sync_runtime() -> Path:
    """Persist a reproducible profile for the active Python runtime."""
    profile = inspect_runtime()
    output = profile_dir() / f"python-{profile['version']}.json"
    output.write_text(json.dumps(profile, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return output


def check_file(path: Path) -> tuple[bool, str | None]:
    """Compile a Hython file with the active interpreter without executing it."""
    try:
        source = path.read_text(encoding="utf-8-sig")
        compile(to_python(source), str(path), "exec")
    except (OSError, UnicodeError, SyntaxError) as exc:
        return False, str(exc)
    return True, None


def check_tree(root: Path) -> list[tuple[Path, str]]:
    """Return syntax failures for all Hython files under a path."""
    paths = [root] if root.is_file() else sorted(root.rglob("*.hy"))
    failures: list[tuple[Path, str]] = []
    for path in paths:
        valid, error = check_file(path)
        if not valid:
            failures.append((path, error or "알 수 없는 오류"))
    return failures
