"""HBC container and instruction model; unrelated to CPython bytecode."""
from __future__ import annotations
import hashlib
import json
import struct
import zlib
from dataclasses import asdict, dataclass
from pathlib import Path

MAGIC = b"HYBC"
VERSION = 1
MAX_COMPRESSED_SIZE = 64 * 1024 * 1024
MAX_INSTRUCTIONS = 1_000_000
_NO_ARG = {"RETURN","POP","NOP","ITER","SET_ITEM","GET_ITEM","FORMAT","NEG","POS","NOT",
           "ADD","SUB","MUL","DIV","FLOORDIV","MOD","POW","EQ","NE","LT","LE","GT","GE","IN","IS","BOOL_AND","BOOL_OR"}
_NAME_ARG = {"LOAD","STORE","GET_ATTR","SET_ATTR","IMPORT"}
_INT_ARG = {"CALL","BUILD_LIST","BUILD_TUPLE","BUILD_DICT","BUILD_STRING"}

@dataclass
class CodeObject:
    name: str
    parameters: list[str]
    constants: list[object]
    instructions: list[list]

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, value: dict) -> "CodeObject":
        return cls(value["name"], value["parameters"], value["constants"], value["instructions"])

class BytecodeError(ValueError):
    pass

def dumps(code: CodeObject) -> bytes:
    raw = json.dumps(code.to_dict(), ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    payload = zlib.compress(raw, level=9)
    digest = hashlib.sha256(payload).digest()
    return MAGIC + bytes([VERSION]) + struct.pack(">I", len(payload)) + digest + payload

def loads(data: bytes) -> CodeObject:
    if len(data) < 41 or data[:4] != MAGIC:
        raise BytecodeError("하이썬 HBC 파일이 아닙니다.")
    if data[4] != VERSION:
        raise BytecodeError(f"지원하지 않는 HBC 버전: {data[4]}")
    size = struct.unpack(">I", data[5:9])[0]
    if size > MAX_COMPRESSED_SIZE:
        raise BytecodeError("HBC 파일이 허용 크기를 초과합니다.")
    digest, payload = data[9:41], data[41:]
    if size != len(payload) or hashlib.sha256(payload).digest() != digest:
        raise BytecodeError("HBC 크기 또는 SHA-256 무결성 검사가 실패했습니다.")
    try:
        decompressor=zlib.decompressobj()
        raw=decompressor.decompress(payload,MAX_COMPRESSED_SIZE+1)
        if len(raw)>MAX_COMPRESSED_SIZE or decompressor.unconsumed_tail:
            raise BytecodeError("HBC 압축 해제 크기가 제한을 초과합니다.")
        value = json.loads(raw.decode("utf-8"))
        code=CodeObject.from_dict(value)
        verify(code)
        return code
    except BytecodeError:
        raise
    except (ValueError, KeyError, TypeError, zlib.error) as exc:
        raise BytecodeError("손상된 HBC 내용입니다.") from exc

def write(path: Path, code: CodeObject) -> None:
    path.write_bytes(dumps(code))

def read(path: Path) -> CodeObject:
    return loads(path.read_bytes())

def verify(code: CodeObject) -> None:
    """Reject malformed programs before the VM executes any instruction."""
    if not isinstance(code.name,str) or not isinstance(code.parameters,list) or not all(isinstance(x,str) for x in code.parameters):
        raise BytecodeError("잘못된 HBC 코드 객체입니다.")
    if len(code.instructions)>MAX_INSTRUCTIONS: raise BytecodeError("HBC 명령어 제한을 초과합니다.")
    count=len(code.instructions)
    for index, ins in enumerate(code.instructions):
        if not isinstance(ins,list) or not ins or not isinstance(ins[0],str):
            raise BytecodeError(f"잘못된 명령어: {index}")
        op=ins[0]; args=ins[1:]
        if op in _NO_ARG:
            if args: raise BytecodeError(f"{op} 명령어 인자 오류")
        elif op in _NAME_ARG:
            if len(args)!=1 or not isinstance(args[0],str): raise BytecodeError(f"{op} 이름 인자 오류")
        elif op in _INT_ARG:
            if len(args)!=1 or not isinstance(args[0],int) or args[0]<0: raise BytecodeError(f"{op} 정수 인자 오류")
        elif op=="CONST":
            if len(args)!=1 or not isinstance(args[0],int) or not 0<=args[0]<len(code.constants): raise BytecodeError("CONST 인덱스 오류")
        elif op in ("JUMP","JUMP_FALSE","FOR_ITER","JUMP_IF_FALSE_OR_POP","JUMP_IF_TRUE_OR_POP"):
            if len(args)!=1 or not isinstance(args[0],int) or not 0<=args[0]<=count: raise BytecodeError(f"{op} 점프 범위 오류")
        elif op in ("MAKE_FUNCTION","MAKE_CLASS"):
            if len(args)!=1 or not isinstance(args[0],dict): raise BytecodeError("중첩 코드 객체 오류")
            try: verify(CodeObject.from_dict(args[0]))
            except (KeyError,TypeError) as exc: raise BytecodeError("중첩 코드 객체 오류") from exc
        else: raise BytecodeError(f"허용되지 않은 HBC 명령어: {op}")
    _verify_stack(code)

def _verify_stack(code: CodeObject) -> None:
    """Follow every reachable branch and reject stack underflow/inconsistent merges."""
    instructions=code.instructions; count=len(instructions)
    pending=[(0,0)]; seen: dict[int,int]={}
    simple_effect={
        "CONST":1,"LOAD":1,"IMPORT":1,"MAKE_FUNCTION":1,"MAKE_CLASS":1,
        "STORE":-1,"POP":-1,"ITER":0,"NOP":0,"FORMAT":0,"GET_ATTR":0,
        "SET_ATTR":-2,"GET_ITEM":-1,"SET_ITEM":-3,
        "NEG":0,"POS":0,"NOT":0,
        "ADD":-1,"SUB":-1,"MUL":-1,"DIV":-1,"FLOORDIV":-1,"MOD":-1,"POW":-1,
        "EQ":-1,"NE":-1,"LT":-1,"LE":-1,"GT":-1,"GE":-1,"IN":-1,"IS":-1,
        "BOOL_AND":-1,"BOOL_OR":-1,
    }
    while pending:
        ip,depth=pending.pop()
        if ip==count: continue
        previous=seen.get(ip)
        if previous is not None:
            if previous!=depth: raise BytecodeError(f"명령어 {ip}의 스택 깊이가 일치하지 않습니다.")
            continue
        seen[ip]=depth; ins=instructions[ip]; op=ins[0]; arg=ins[1] if len(ins)>1 else None
        if op=="RETURN":
            if depth<1: raise BytecodeError(f"명령어 {ip}에서 스택 언더플로")
            continue
        if op=="JUMP": pending.append((arg,depth)); continue
        if op=="JUMP_FALSE":
            if depth<1: raise BytecodeError(f"명령어 {ip}에서 스택 언더플로")
            pending.extend(((arg,depth-1),(ip+1,depth-1))); continue
        if op in ("JUMP_IF_FALSE_OR_POP","JUMP_IF_TRUE_OR_POP"):
            if depth<1: raise BytecodeError(f"명령어 {ip}에서 스택 언더플로")
            pending.extend(((arg,depth),(ip+1,depth-1))); continue
        if op=="FOR_ITER":
            if depth<1: raise BytecodeError(f"명령어 {ip}에서 스택 언더플로")
            pending.extend(((arg,depth-1),(ip+1,depth+1))); continue
        if op=="CALL": effect=-arg
        elif op in ("BUILD_LIST","BUILD_TUPLE","BUILD_STRING"): effect=1-arg
        elif op=="BUILD_DICT": effect=1-(arg*2)
        else: effect=simple_effect[op]
        new_depth=depth+effect
        if new_depth<0: raise BytecodeError(f"명령어 {ip}에서 스택 언더플로")
        pending.append((ip+1,new_depth))
