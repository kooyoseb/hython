"""Canonical Hython vocabulary.

The spellings deliberately follow pronunciation rather than Korean meaning.
Aliases can be accepted, but reverse translation always emits the canonical form.
"""

KEYWORDS: dict[str, str] = {
    "False": "폴스", "None": "넌", "True": "트루",
    "and": "앤드", "as": "애즈", "assert": "어설트",
    "async": "어싱크", "await": "어웨이트", "break": "브레이크",
    "class": "클래스", "continue": "컨티뉴", "def": "데프",
    "del": "델", "elif": "엘리프", "else": "엘스",
    "except": "익셉트", "finally": "파이널리", "for": "포",
    "from": "프롬", "global": "글로벌", "if": "이프",
    "import": "인폴트", "in": "인", "is": "이즈",
    "lambda": "람다", "nonlocal": "논로컬", "not": "낫",
    "or": "오어", "pass": "패스", "raise": "레이즈",
    "return": "리턴", "try": "트라이", "while": "와일",
    "with": "위드", "yield": "일드", "match": "매치",
    "case": "케이스", "type": "타입",
}

BUILTINS: dict[str, str] = {
    "print": "프린트", "input": "인풋", "len": "렌",
    "range": "레인지", "str": "스트링", "int": "인트",
    "float": "플로트", "bool": "불", "list": "리스트",
    "dict": "딕트", "set": "셋", "tuple": "튜플",
    "open": "오픈", "enumerate": "이뉴머레이트", "zip": "집",
    "map": "맵", "filter": "필터", "sum": "썸", "min": "민",
    "max": "맥스", "abs": "앱스", "round": "라운드",
    "sorted": "소티드", "reversed": "리버스드", "super": "수퍼",
    "object": "오브젝트", "property": "프로퍼티",
    "staticmethod": "스태틱메서드", "classmethod": "클래스메서드",
    "isinstance": "이즈인스턴스", "issubclass": "이즈서브클래스",
    "Exception": "익셉션", "ValueError": "밸류에러",
    "TypeError": "타입에러", "NameError": "네임에러",
}

PYTHON_TO_HYTHON = KEYWORDS | BUILTINS
HYTHON_TO_PYTHON = {spoken: python for python, spoken in PYTHON_TO_HYTHON.items()}

# Accepted conveniences which are not emitted by to_hython().
HYTHON_TO_PYTHON.update({"임포트": "import", "널": "None"})

