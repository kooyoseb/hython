"""Hython-owned AST and parser for the native compiler path."""
from __future__ import annotations
from dataclasses import dataclass, field
import io
import token as token_types
import tokenize
from .package_manager import load_dictionaries
from .vocabulary import HYTHON_TO_PYTHON

@dataclass
class Node:
    kind: str
    value: object = None
    children: list["Node"] = field(default_factory=list)
    line: int = 0

class ParseError(SyntaxError): pass

def lex(source: str) -> list[tuple[int,str,int]]:
    names = load_dictionaries() | HYTHON_TO_PYTHON
    result=[]
    try: stream=tokenize.generate_tokens(io.StringIO(source).readline)
    except Exception as exc: raise ParseError(str(exc)) from exc
    try:
        for item in stream:
            if item.type in (tokenize.ENCODING, tokenize.COMMENT, tokenize.NL): continue
            text=names.get(item.string,item.string) if item.type==tokenize.NAME else item.string
            result.append((item.type,text,item.start[0]))
    except (tokenize.TokenError,IndentationError) as exc: raise ParseError(str(exc)) from exc
    return result

class Parser:
    def __init__(self, source: str): self.tokens=lex(source); self.pos=0
    def current(self): return self.tokens[self.pos] if self.pos<len(self.tokens) else (tokenize.ENDMARKER,"",0)
    def text(self): return self.current()[1]
    def take(self, text=None):
        token=self.current()
        if text is not None and token[1]!=text: raise ParseError(f"'{text}' 필요 (줄 {token[2]})")
        self.pos+=1; return token
    def skip_newlines(self):
        while self.current()[0] in (tokenize.NEWLINE,): self.pos+=1
    def parse(self):
        body=[]; self.skip_newlines()
        while self.current()[0]!=tokenize.ENDMARKER:
            body.append(self.statement()); self.skip_newlines()
        return Node("module",children=body)
    def suite(self):
        self.take(":"); self.take_newline(); self.expect_type(tokenize.INDENT)
        body=[]; self.skip_newlines()
        while self.current()[0] not in (tokenize.DEDENT,tokenize.ENDMARKER):
            body.append(self.statement()); self.skip_newlines()
        self.expect_type(tokenize.DEDENT); return body
    def take_newline(self):
        if self.current()[0]!=tokenize.NEWLINE: raise ParseError(f"줄 끝 필요 (줄 {self.current()[2]})")
        self.pos+=1
    def expect_type(self, kind):
        if self.current()[0]!=kind: raise ParseError(f"잘못된 들여쓰기 (줄 {self.current()[2]})")
        self.pos+=1
    def statement(self):
        line=self.current()[2]; word=self.text()
        if word=="import":
            self.take(); module=self.take()[1]; alias=module
            if self.text()=="as": self.take(); alias=self.take()[1]
            self.take_newline(); return Node("import",(module,alias),line=line)
        if word=="def":
            self.take(); name=self.take()[1]; self.take("("); params=[]
            if self.text()!=")":
                while True:
                    params.append(self.take()[1])
                    if self.text()!=",": break
                    self.take(",")
            self.take(")"); return Node("def",(name,params),self.suite(),line)
        if word=="class":
            self.take(); name=self.take()[1]
            if self.text()=="(":
                self.take("(")
                if self.text()!=")": raise ParseError(f"네이티브 클래스 상속은 아직 지원하지 않습니다 (줄 {line})")
                self.take(")")
            return Node("class",name,self.suite(),line)
        if word in ("if","while"):
            self.take(); test=self.expression(); body=self.suite(); other=[]
            if word=="if" and self.text()=="else": self.take(); other=self.suite()
            return Node(word,None,[test,Node("body",children=body),Node("body",children=other)],line)
        if word=="for":
            self.take(); name=self.take()[1]; self.take("in"); iterable=self.expression()
            return Node("for",name,[iterable,Node("body",children=self.suite())],line)
        if word=="return":
            self.take(); value=Node("constant",None,line=line) if self.current()[0]==tokenize.NEWLINE else self.expression()
            self.take_newline(); return Node("return",children=[value],line=line)
        if word in ("break","continue"):
            self.take(); self.take_newline(); return Node(word,line=line)
        if word=="pass": self.take(); self.take_newline(); return Node("pass",line=line)
        expression=self.expression()
        if self.text() in ("+=","-=","*=","/=","//=","%=","**="):
            if expression.kind!="name": raise ParseError(f"복합 대입 대상은 이름이어야 합니다 (줄 {line})")
            op=self.take()[1][:-1]; value=self.expression(); self.take_newline()
            return Node("augassign",(expression.value,op),[value],line)
        if self.text()=="=":
            if expression.kind not in ("name","attribute","subscript"): raise ParseError(f"잘못된 대입 대상 (줄 {line})")
            self.take("="); value=self.expression(); self.take_newline(); return Node("assign",children=[expression,value],line=line)
        self.take_newline(); return Node("expr",children=[expression],line=line)

    PRECEDENCE={"or":1,"and":2,"==":3,"!=":3,"<":3,"<=":3,">":3,">=":3,"in":3,"is":3,
                "+":4,"-":4,"*":5,"/":5,"//":5,"%":5,"**":6}
    def expression(self, minimum=0):
        line=self.current()[2]; word=self.text()
        if word in ("-","+","not"):
            self.take(); left=Node("unary",word,[self.expression(6)],line)
        elif word=="(":
            self.take(); left=self.expression(); self.take(")")
        elif self.current()[0] == getattr(tokenize,"FSTRING_START",-1):
            self.take(); parts=[]
            while self.current()[0] != getattr(tokenize,"FSTRING_END",-2):
                if self.current()[0] == getattr(tokenize,"FSTRING_MIDDLE",-3):
                    parts.append(Node("constant",self.take()[1],line=line))
                elif self.text()=="{":
                    self.take("{"); parts.append(Node("format",children=[self.expression()],line=line)); self.take("}")
                else: raise ParseError(f"지원하지 않는 f-string 형식 (줄 {line})")
            self.take(); left=Node("fstring",children=parts,line=line)
        elif self.current()[0] in (tokenize.NUMBER,tokenize.STRING):
            raw=self.take()[1]
            import ast
            left=Node("constant",ast.literal_eval(raw),line=line)
        elif word in ("True","False","None"):
            self.take(); left=Node("constant",{"True":True,"False":False,"None":None}[word],line=line)
        elif word=="[":
            self.take(); values=[]
            if self.text()!="]":
                while True:
                    values.append(self.expression())
                    if self.text()!=",": break
                    self.take(",")
            self.take("]"); left=Node("list",children=values,line=line)
        elif word=="{":
            self.take(); pairs=[]
            if self.text()!="}":
                while True:
                    key=self.expression(); self.take(":"); value=self.expression()
                    pairs.append(Node("pair",children=[key,value],line=line))
                    if self.text()!=",": break
                    self.take(",")
            self.take("}"); left=Node("dict",children=pairs,line=line)
        else:
            left=Node("name",self.take()[1],line=line)
        while self.text() in ("(", ".", "["):
            if self.text()=="(":
                self.take(); args=[]
                if self.text()!=")":
                    while True:
                        args.append(self.expression())
                        if self.text()!=",": break
                        self.take(",")
                self.take(")"); left=Node("call",children=[left,*args],line=line)
            elif self.text()==".":
                self.take("."); left=Node("attribute",self.take()[1],[left],line)
            else:
                self.take("["); index=self.expression(); self.take("]")
                left=Node("subscript",children=[left,index],line=line)
        while self.text() in self.PRECEDENCE and self.PRECEDENCE[self.text()]>=minimum:
            op=self.take()[1]; precedence=self.PRECEDENCE[op]
            right=self.expression(precedence+(0 if op=="**" else 1))
            left=Node("binary",op,[left,right],line)
        return left

def parse(source: str) -> Node: return Parser(source).parse()
