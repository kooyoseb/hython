# 하이썬 (Hython)

[![PyPI](https://img.shields.io/pypi/v/hython-lang?label=PyPI&color=3776ab)](https://pypi.org/project/hython-lang/)
[![Python](https://img.shields.io/pypi/pyversions/hython-lang?label=Python)](https://pypi.org/project/hython-lang/)
[![License](https://img.shields.io/pypi/l/hython-lang?label=License)](LICENSE)
[![Status](https://img.shields.io/badge/status-stable-brightgreen)](CHANGELOG.md)

> Python, pronounced in Hangul.

하이썬은 Python의 의미를 번역하는 대신 영어 발음을 한글로 적는 난해한 프로그래밍
언어입니다. Python 호환 실행기와 독립 HBC 컴파일러·가상 머신을 함께 제공합니다.

```hython
데프 인사(이름):
    프린트(에프"안녕, {이름}!")

포 번호 인 레인지(3):
    인사(에프"하이썬 {번호}")
```

## 빠른 설치

Python 3.14 이상이 필요합니다.

```console
py -3.14 -m pip install hython-lang
hython --version
```

현재 공개 버전은 [PyPI의 `hython-lang`](https://pypi.org/project/hython-lang/)에서
설치할 수 있습니다.

Windows에서는 GitHub Release의 `Hython-버전-setup.exe`를 사용할 수 있습니다.
설치 프로그램은 한국어와 영어를 지원하며 PATH, 시작 메뉴, 바탕화면 바로가기를
선택적으로 설치합니다. 자동 배포와 Winget에는 x64 MSI를 사용합니다.

## 첫 실행

`안녕.hy` 파일을 만듭니다.

```hython
이름 = "하이썬"
프린트(에프"안녕, {이름}!")
```

실행합니다.

```console
hython 소스실행 안녕.hy
```

영어 명령도 동일하게 지원합니다.

```console
hython run 안녕.hy
```

## 주요 특징

- Python 키워드와 내장 함수의 한글 발음형 문법
- Python 3.14 호환 실행 모드
- 하이썬 전용 AST, HIR, HBC 바이트코드와 가상 머신
- `.pyc` 및 CPython opcode와 다른 독립 HBC 형식
- 한글 오류 메시지와 traceback
- 표준 라이브러리 및 설치 패키지 공개 API 발음 사전
- 패키지 설치·업데이트·제거와 문법 사전 자동 동기화
- Python 파일의 완전 한글 변환과 영어 식별자 감사
- HBC 프로그램의 독립 Windows EXE 빌드
- Nuitka/MSVC 기반 C 변환 하이썬 실행 파일
- HBC 컴파일러 검증·업데이트·롤백

## 문법 예시

### 조건과 반복

```hython
합계 = 0

포 숫자 인 레인지(10):
    이프 숫자 % 2 == 0:
        합계 += 숫자

프린트(합계)
```

### 함수와 클래스

```hython
클래스 사람:
    데프 __이니트__(셀프, 이름):
        셀프.이름 = 이름

    데프 인사(셀프):
        리턴 에프"안녕하세요, {셀프.이름}입니다."

사용자 = 사람("하이썬")
프린트(사용자.인사())
```

### 예외 처리

```hython
트라이:
    값 = 인트(인풋("숫자: "))
    프린트(10 / 값)
익셉트 밸류에러:
    프린트("숫자를 입력해야 합니다.")
익셉트 제로디비전에러:
    프린트("0으로 나눌 수 없습니다.")
```

### 모듈

```hython
인폴트 제이슨

자료 = 제이슨.로드스('{"값": 42}')
프린트(자료["값"])
```

설치·동기화된 발음 사전에 따라 실제 모듈 철자가 달라질 수 있습니다. 생성된 사전은
`~/.hython/dictionaries`에서 확인하고 수정할 수 있습니다.

### Tkinter

Tkinter는 pip 패키지가 아니라 Python의 Tcl/Tk 구성 요소입니다. Tcl/Tk가 포함된 공식
Python 환경에서는 다음처럼 영어 API 없이 작성할 수 있습니다.

```hython
인폴트 티킨터 애즈 티케이

창 = 티케이.티케이()
창.타이틀("하이썬")
창.지오메트리("500x300")
창.메인루프()
```

## 문자열 접두사

문자열 접두사도 한글로 쓸 수 있습니다.

| Python | 하이썬 |
|---|---|
| `f"..."` | `에프"..."` |
| `r"..."` | `알"..."` |
| `b"..."` | `비"..."` |
| `u"..."` | `유"..."` |
| `rf"..."` | `알에프"..."` |

문자열 내용, URL, 실제 파일 경로와 환경 변수명은 외부 시스템에 전달되는 데이터이므로
원문을 보존합니다.

## 명령어

영어 명령과 한글 별칭을 함께 제공합니다.

| 기능 | 한글 명령 | 영어 명령 |
|---|---|---|
| 소스 실행 | `hython 소스실행 파일.hy` | `hython run 파일.hy` |
| 대화형 실행 | `hython 대화` | `hython repl` |
| HBC 컴파일 | `hython 컴파일 파일.hy` | `hython compile 파일.hy` |
| HBC 실행 | `hython 바이트실행 파일.hbc` | `hython execute 파일.hbc` |
| 프로젝트 빌드 | `hython 빌드 .` | `hython build .` |
| EXE 생성 | `hython 실행파일 파일.hbc` | `hython exe 파일.hbc` |
| 영어 감사 | `hython 감사 .` | `hython audit .` |
| 업데이트 | `hython 업데이트` | `hython update` |
| 환경 진단 | `hython 진단` | `hython doctor` |

전체 도움말:

```console
hython --help
hython 명령 --help
```

## Python 코드 변환

일반 Python 파일을 하이썬으로 변환합니다.

```console
hython 변환 program.py --reverse -o program.hy
```

사용자 식별자와 문자열 접두사까지 한글화합니다.

```console
hython 변환 program.py --reverse --complete -o 완전한글.hy
hython 감사 완전한글.hy
```

하이썬을 Python으로 되돌릴 수도 있습니다.

```console
hython 변환 program.hy -o program.py
```

## 패키지 관리

패키지를 설치하면 배포판의 import 모듈을 찾고 Python 소스와 공개 런타임 API를 분석해
발음 사전을 생성합니다.

```console
hython 패키지 설치 requests
hython 패키지 설치 beautifulsoup4
hython 패키지 제거 requests
```

설치된 모듈을 다시 분석합니다.

```console
hython 패키지 분석 requests
```

신뢰하지 않는 모듈은 실행 없는 정적 분석만 사용할 수 있습니다.

```console
hython 패키지 분석 모듈명 --static
```

## Python 런타임 업데이트

```console
hython 초기화
hython 업데이트
hython 업데이트 --no-runtime
hython 런타임 정보
hython 런타임 동기화
hython 런타임 검사 .
```

`업데이트`는 Windows의 공식 Python install manager를 통해 런타임을 갱신하고, 새
Python의 문법 프로필·표준 라이브러리·설치 패키지 발음 사전을 재생성합니다.

Python 호환 실행 모드는 활성 Python이 지원하는 문법을 바로 사용합니다. 새로운 문법을
독립 HBC 명령으로 변환하려면 해당 문법을 지원하는 HBC 컴파일러 릴리스가 필요합니다.

## HBC 컴파일러와 VM

```console
hython 컴파일 examples\컴파일.hy -o 프로그램.hbc
hython 바이트실행 프로그램.hbc
hython 해체 프로그램.hbc
```

HBC는 `HYBC` 헤더, 자체 스택 명령어, 압축 페이로드와 SHA-256 무결성 검사를
사용합니다. 원본 `.hy` 파일이나 CPython `.pyc` 없이 Hython VM에서 실행됩니다.

### 프로젝트 빌드

```console
hython 빌드 프로젝트 -o dist
hython 바이트실행 dist\main.hbc
```

### Windows EXE

EXE 빌드 기능을 설치합니다.

```console
py -3.14 -m pip install "hython-lang[exe]"
```

HBC를 독립 실행 파일로 만듭니다.

```console
hython 실행파일 프로그램.hbc -o 프로그램.exe
hython 실행파일 프로그램.hbc -o 프로그램.exe --windowed --icon app.ico
```

## 소스에서 개발

저장소를 받은 뒤 개발 모드로 설치합니다.

```console
py -3.14 -m pip install -e ".[exe,native,publish]"
py -3.14 -m unittest discover -s tests -q
```

현재 테스트 수와 최신 변경 사항은 [CHANGELOG.md](CHANGELOG.md)에서 확인할 수 있습니다.

## C 기반 하이썬 실행 파일 빌드

Windows에서 다음 도구가 필요합니다.

- Python 3.14
- Visual Studio 또는 Build Tools의 MSVC C/C++ 도구
- Nuitka

```console
build-hython.bat
```

빌드 과정:

```text
전체 회귀 테스트
→ Nuitka C 소스 생성
→ MSVC 컴파일 및 링크
→ release\hython.exe 생성
→ HBC smoke test
```

생성 파일:

```text
release\hython.exe
release\hython.exe.sha256
release\hython-native-report.xml
```

## Windows 설치 프로그램

WiX가 설치된 환경에서 MSI를 생성합니다.

```console
build-installer.bat
```

MSI는 Program Files 설치, 시스템 PATH, 시작 메뉴 바로가기와 Windows 제거·업그레이드를
지원합니다.

## PyPI 배포

배포 파일만 생성하고 검증합니다.

```console
publish-pypi.bat
```

TestPyPI 또는 실제 PyPI에 게시합니다.

```console
publish-pypi.bat testpypi
publish-pypi.bat pypi
```

PyPI 버전은 재사용할 수 없습니다. 공개 후 수정판은 `2.0.1`, `2.0.2`처럼 새 버전으로
게시해야 합니다.

## 프로젝트 구조

```text
src/hython/       하이썬 실행기·컴파일러·VM
tests/            회귀 및 호환성 테스트
examples/         하이썬 예제
docs/             언어와 컴파일러 문서
scripts/          빌드·검증·배포 도구
installer/        Windows MSI 정의
assets/           아이콘과 이미지
```

## 기여

버그 제보와 기능 제안은 GitHub Issues를 이용해 주세요. 변경을 제안할 때는 다음을
확인해 주세요.

1. 기존 테스트가 모두 통과하는지 확인합니다.
2. 변경한 동작의 회귀 테스트를 추가합니다.
3. 사용자에게 보이는 오류와 도움말은 가능한 한 한국어로 작성합니다.
4. 공개 API 또는 문법 변경은 `CHANGELOG.md`에 기록합니다.

## 보안

취약점은 공개 Issue보다 [SECURITY.md](SECURITY.md)의 절차를 따라 비공개로 제보해
주세요. PyPI 토큰, 인증서 암호와 개인 키를 Issue·커밋·로그에 포함하지 마세요.

## 라이선스

하이썬은 [MIT License](LICENSE)로 배포됩니다.
